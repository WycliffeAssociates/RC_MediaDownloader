# Contributing to the English Unlocked Literal Bible

Thank you for your help!

If you have a suggestion to be made, you have one of two options:

1. Fork this repository, make the change and create a pull request. We'll review it and merge it in.
1. [Submit an issue](https://git.door43.org/Door43/en_ulb/issues/new). Please be detailed in your report.

